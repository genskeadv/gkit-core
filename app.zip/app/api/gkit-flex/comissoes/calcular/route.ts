import { requireGkitFlexApiAccess } from '@/features/gkit-flex/api-auth';
import { NextRequest } from 'next/server';
import { getCicloClientesForComissoes } from '@/features/gkit-flex/ciclo-clientes';
import { buildCommissionWorkbook, processCommissionWithClients } from '@/features/gkit-flex/comissoes/commissionProcessor';
import { saveCommissionExecution } from '@/features/gkit-flex/comissoes/supabasePersistence';
import type { CommissionProcessResult } from '@/features/gkit-flex/comissoes/types';

export const runtime = 'nodejs';

function buildResumo(result: CommissionProcessResult) {
  const commissionSummaries = result.summaries.map((row) => ({ ...row, normalizedCategoria: normalizeText(row.categoria) }));
  const byKey = new Map<string, {
    categoria: string;
    carteira: string;
    quantidadeLancamentos: number;
    valorRecebido: number;
    valorAposReducao: number;
    comissaoFinal: number;
  }>();

  for (const row of result.enrichedRows) {
    if (row.valorRecebido <= 0) continue;

    const normalizedCategoria = normalizeText(row.categoria);
    const matchingCommission = commissionSummaries.find((summary) => (
      normalizedCategoria &&
      summary.carteira === row.vendedor &&
      (summary.normalizedCategoria.includes(normalizedCategoria) || normalizedCategoria.includes(summary.normalizedCategoria))
    ));
    const categoria = matchingCommission?.categoria || row.categoria || 'Sem categoria';
    const carteira = row.vendedor || 'Sem vendedor';
    const key = `${categoria}::${carteira}`;
    const current = byKey.get(key) || {
      categoria,
      carteira,
      quantidadeLancamentos: 0,
      valorRecebido: 0,
      valorAposReducao: 0,
      comissaoFinal: 0,
    };

    current.quantidadeLancamentos += 1;
    current.valorRecebido = roundMoney(current.valorRecebido + row.valorRecebido);
    byKey.set(key, current);
  }

  for (const row of result.summaries) {
    const key = `${row.categoria}::${row.carteira}`;
    const current = byKey.get(key) || {
      categoria: row.categoria,
      carteira: row.carteira,
      quantidadeLancamentos: row.quantidadeLancamentos,
      valorRecebido: row.valorRecebido,
      valorAposReducao: 0,
      comissaoFinal: 0,
    };
    current.valorAposReducao = row.valorAposReducao;
    current.comissaoFinal = row.comissaoFinal;
    byKey.set(key, current);
  }

  return Array.from(byKey.values()).sort((a, b) => a.categoria.localeCompare(b.categoria) || b.valorRecebido - a.valorRecebido);
}

function buildTotals(resumo: ReturnType<typeof buildResumo>) {
  return resumo.reduce(
    (acc, row) => ({
      valorRecebido: Math.round((acc.valorRecebido + row.valorRecebido) * 100) / 100,
      valorAposReducao: Math.round((acc.valorAposReducao + row.valorAposReducao) * 100) / 100,
      comissaoFinal: Math.round((acc.comissaoFinal + row.comissaoFinal) * 100) / 100,
    }),
    { valorRecebido: 0, valorAposReducao: 0, comissaoFinal: 0 },
  );
}

function normalizeText(value: unknown): string {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ');
}

function roundMoney(value: number): number {
  return Math.round((value || 0) * 100) / 100;
}

export async function POST(request: NextRequest) {
  try {
    const accessError = await requireGkitFlexApiAccess();
    if (accessError) return accessError;
    const formData = await request.formData();
    const contasFile = formData.get('contasReceber');
    const competencia = String(formData.get('competencia') || '');
    const action = String(formData.get('action') || 'download');

    if (!(contasFile instanceof File)) {
      return Response.json(
        { error: 'Envie o arquivo de contas a receber.' },
        { status: 400 },
      );
    }

    const contasBuffer = await contasFile.arrayBuffer();
    const clientesCiclo = await getCicloClientesForComissoes();

    const result = processCommissionWithClients(contasBuffer, clientesCiclo);
    const resumo = buildResumo(result);
    const totals = buildTotals(resumo);

    if (action === 'preview') {
      return Response.json({
        arquivo: contasFile.name,
        competencia,
        resumo,
        totals,
        auditCount: result.auditRows.length,
      });
    }

    const saveResult = await saveCommissionExecution({
      competencia,
      contasFileName: contasFile.name,
      clientesFileName: 'ciclo.clientes',
      result,
    });

    if (action === 'save') {
      return Response.json({
        arquivo: contasFile.name,
        competencia,
        resumo,
        totals,
        auditCount: result.auditRows.length,
        saved: saveResult.saved,
        executionId: saveResult.executionId,
        warning: saveResult.warning ?? null,
      });
    }

    const output = buildCommissionWorkbook(result);

    return new Response(new Uint8Array(output), {
      status: 200,
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': 'attachment; filename="comissoes_mensais.xlsx"',
        'X-Commission-Summary': encodeURIComponent(JSON.stringify(resumo)),
        'X-Audit-Count': String(result.auditRows.length),
        'X-Commission-Execution-Id': saveResult.executionId ?? '',
        'X-Commission-Saved': saveResult.saved ? 'true' : 'false',
        'X-Commission-Warning': encodeURIComponent(saveResult.warning ?? ''),
      },
    });
  } catch (error) {
    console.error('[comissoes/calcular]', error);
    return Response.json(
      { error: error instanceof Error ? error.message : 'Erro ao calcular comissoes.' },
      { status: 500 },
    );
  }
}
